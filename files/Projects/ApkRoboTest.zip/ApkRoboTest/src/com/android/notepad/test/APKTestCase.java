package com.android.notepad.test;

import com.jayway.android.robotium.solo.*;

import android.test.ActivityInstrumentationTestCase2;

@SuppressWarnings("unchecked")
public class APKTestCase extends ActivityInstrumentationTestCase2{
	
	private Solo mySolo; 
	private static final String Launcher_Activity_ClassName  = "com.example.android.notepad.NotesList";	
	private static Class launcherActivityClass;
	static{
		try{
			launcherActivityClass = Class.forName(Launcher_Activity_ClassName);
		}catch (ClassNotFoundException ex) {
			throw new RuntimeException(ex);
		}		
	}

	public APKTestCase() throws ClassNotFoundException
	{
		super(launcherActivityClass);
	}
	
	@Override
	public void setUp() throws Exception
	{
		mySolo = new Solo(getInstrumentation(), getActivity());
	}
	@Override
	public void tearDown() throws Exception
	{
		mySolo.finishOpenedActivities();
	}
	
	public void testAddNote() throws Exception {
		mySolo.clickOnMenuItem("Add note");		
		mySolo.assertCurrentActivity("Expected NoteEditor activity", "NoteEditor"); 		
		mySolo.enterText(0, "First Note");
		mySolo.goBack(); 		
		assertTrue(mySolo.searchText("First Note"));
		mySolo.clickOnMenuItem("Add note");		
		mySolo.typeText(0, "Second Note ");		
		mySolo.goBack(); 
		assertTrue(mySolo.searchText("Second Note"));
		//Screenshot saves in "/sdcard/Robotium-Screenshots/".
		mySolo.takeScreenshot();
		boolean expected = true;
		boolean actual = mySolo.searchText("First Note") && mySolo.searchText("Second Note");	
		assertEquals("First Note and/or Second Note are not found", expected, actual); 

	}
	
	
	
}
