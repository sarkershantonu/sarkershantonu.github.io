package com.notepad.test;

import android.test.*;
import com.example.android.notepad.*;
import com.jayway.android.robotium.solo.Solo;

public class TestNoteAdministration extends ActivityInstrumentationTestCase2<NotesList> {

	private Solo mySolo;
	public TestNoteAdministration() {
		super(NotesList.class);		
	}
	@Override
	public void setUp() throws Exception {		
		mySolo = new Solo(getInstrumentation(), getActivity());
	}

	@Override
	public void tearDown() throws Exception {		
		mySolo.finishOpenedActivities();
	}
	public void testAddNote() throws Exception {
		mySolo.clickOnMenuItem("Add note");		
		mySolo.assertCurrentActivity("Expected NoteEditor activity", "NoteEditor"); 		
		mySolo.enterText(0, "First Note");
		mySolo.goBack(); 		
		assertTrue(mySolo.searchText("First Note"));
		mySolo.clickOnMenuItem("Add note");		
		mySolo.typeText(0, "Second Note ");		
		mySolo.goBack(); 
		assertTrue(mySolo.searchText("Second Note"));
		//Screenshot saves in "/sdcard/Robotium-Screenshots/".
		mySolo.takeScreenshot();
		boolean expected = true;
		boolean actual = mySolo.searchText("Note 1") && mySolo.searchText("Note 2");		
		assertEquals("First Note and/or Second Note are not found", expected, actual); 

	}
	
	public void testEditNote() throws Exception {
		
		mySolo.clickInList(2); 		
		mySolo.hideSoftKeyboard();		
		mySolo.setActivityOrientation(Solo.LANDSCAPE);		
		mySolo.clickOnMenuItem("Edit title");		
		mySolo.enterText(0, " test");  
		mySolo.goBack();
		boolean expected = true;		
		boolean actual = mySolo.waitForText("(?i).*?First Note test"); 		
		assertEquals("First Note test is not found", expected, actual); 

	}
	
	public void testRemoveNote() throws Exception {

		mySolo.clickOnText("(?i).*?test.*");

		mySolo.clickOnMenuItem("Delete");
		//Note 1 test & Note 2 should not be found
		boolean expected = false;   
		boolean actual = mySolo.searchText("First Note test");
		//Assert that Note 1 test is not found
		assertEquals("First Note Test is found", expected, actual);  
		mySolo.clickLongOnText("Second Note");
		//Clicks on Delete in the context menu
		mySolo.clickOnText("Delete");  
		//Will wait 100 milliseconds for the text: "Note 2"
		actual = mySolo.waitForText("Second Note ", 1, 100);
		//Assert that Note 2 is not found
		assertEquals("Second Note is found", expected, actual);  
	}

}
