/** Automatically generated file. DO NOT MODIFY */
package com.notepad.test;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}