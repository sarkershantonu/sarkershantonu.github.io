package com.android.notepad.test;

import com.jayway.android.robotium.solo.Solo;

import android.test.ActivityInstrumentationTestCase2;

public class ApkTestTemplate extends ActivityInstrumentationTestCase2{
	
	private Solo mySolo; 
	private static final String Launcher_Activity_ClassName  = "com.example.android.notepad.NotesList";	
	private static Class launcherActivityClass;
	static{
		try{
			launcherActivityClass = Class.forName(Launcher_Activity_ClassName);
		}catch (ClassNotFoundException ex) {
			throw new RuntimeException(ex);
		}		
	}

	public ApkTestTemplate() {
		super(launcherActivityClass);
	}
	
	@Override
	public void setUp() throws Exception
	{
		mySolo = new Solo(getInstrumentation(), getActivity());
	}
	@Override
	public void tearDown() throws Exception
	{
		mySolo.finishOpenedActivities();
	}
	public Solo getSolo()
	{
		return this.mySolo;
	}
}
