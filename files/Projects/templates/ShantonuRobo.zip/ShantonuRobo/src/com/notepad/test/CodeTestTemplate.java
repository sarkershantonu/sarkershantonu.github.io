package com.notepad.test;

import android.test.ActivityInstrumentationTestCase2;

import com.example.android.notepad.NotesList;
import com.jayway.android.robotium.solo.Solo;

public class CodeTestTemplate extends ActivityInstrumentationTestCase2<NotesList>{
	
	private Solo mySolo;
	public CodeTestTemplate() {
		super(NotesList.class);		
	}
	@Override
	public void setUp() throws Exception {		
		mySolo = new Solo(getInstrumentation(), getActivity());
	}

	@Override
	public void tearDown() throws Exception {		
		mySolo.finishOpenedActivities();
	}
	public Solo getSolo()
	{
		return this.mySolo;
	}
}
