package com.notepad.test;

import com.jayway.android.robotium.solo.Solo;

public class OnlyTestCase extends CodeTestTemplate{
	private Solo mySolo;

	public OnlyTestCase()
	{
		super();		
	}
	public void setUp() throws Exception
	{
		super.setUp(); 
		this.mySolo= super.getSolo();
	}
	public void tearDown() throws Exception
	{
		super.tearDown();
	}
	
	public void testAddNote() throws Exception {
		mySolo.clickOnMenuItem("Add note");		
		mySolo.assertCurrentActivity("Expected NoteEditor activity", "NoteEditor"); 		
		mySolo.enterText(0, "First Note");
		mySolo.goBack(); 		
		assertTrue(mySolo.searchText("First Note"));
		mySolo.clickOnMenuItem("Add note");		
		mySolo.typeText(0, "Second Note ");		
		mySolo.goBack(); 
		assertTrue(mySolo.searchText("Second Note"));
		//Screenshot saves in "/sdcard/Robotium-Screenshots/".
		mySolo.takeScreenshot();
		boolean expected = true;
		boolean actual = mySolo.searchText("First Note") && mySolo.searchText("Second Note");		
		assertEquals("First Note and/or Second Note are not found", expected, actual); 

	}	
	
}
