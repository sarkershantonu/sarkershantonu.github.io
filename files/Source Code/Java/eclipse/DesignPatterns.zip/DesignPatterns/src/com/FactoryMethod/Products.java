package com.FactoryMethod;

public enum Products {pen,pencil,eraser}
