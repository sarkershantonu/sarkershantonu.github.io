package com.abstractfactory;

public interface IToilet {
	public String toString();
}
