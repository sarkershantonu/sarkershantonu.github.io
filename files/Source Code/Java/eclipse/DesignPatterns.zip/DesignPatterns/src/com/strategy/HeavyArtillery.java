package com.strategy;

public class HeavyArtillery implements IStrategyBehaviour{
	public void carry() {
		System.out.println("carrying heavy artillery");		
	}
}
