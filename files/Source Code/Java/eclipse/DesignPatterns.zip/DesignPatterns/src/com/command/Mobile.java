package com.command;

public class Mobile {
	public static MobileReceiver getAMobile(){
		return new MobileReceiver();
	}
}
