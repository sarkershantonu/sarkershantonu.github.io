package com.FactoryMethod;

public class Pen implements IProduct{
	public void showMe(){
		System.out.println("A Pen is made");
	}
}
