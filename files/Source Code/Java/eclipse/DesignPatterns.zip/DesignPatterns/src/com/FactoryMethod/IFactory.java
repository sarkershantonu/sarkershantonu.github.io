package com.FactoryMethod;

public interface IFactory {
	//The Factory method
	IProduct createProduct();		
}
