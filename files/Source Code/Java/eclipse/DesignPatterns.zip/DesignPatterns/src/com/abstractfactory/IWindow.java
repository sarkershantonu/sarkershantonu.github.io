package com.abstractfactory;

public interface IWindow {
	public String toString();
}
