package com.iteratorPattern;

import java.util.Iterator;

public interface IBookIterator {
	public Iterator createIterator();
}
