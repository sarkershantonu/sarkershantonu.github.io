package com.proxy;

public interface IAccount {
	public String getLastAccessDate();
}
