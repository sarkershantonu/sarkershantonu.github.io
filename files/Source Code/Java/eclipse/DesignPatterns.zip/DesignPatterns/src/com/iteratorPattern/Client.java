package com.iteratorPattern;

public class Client {
	public static void main(String[] args) {
		new BookManager().showAllBooks();
	}
}
