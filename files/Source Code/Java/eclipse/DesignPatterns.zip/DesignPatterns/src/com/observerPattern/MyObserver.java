package com.observerPattern;

public abstract class MyObserver {
	public abstract void update();
	public abstract void update(Object args);
}
