package com.FactoryMethod;

public class Pencil implements IProduct{
	public void showMe(){
		System.out.println("A Pencil is made");
	}
}
