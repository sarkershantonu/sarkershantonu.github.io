package com.Composite;

public interface IComponent {
	public void displayBookInfo();
}
