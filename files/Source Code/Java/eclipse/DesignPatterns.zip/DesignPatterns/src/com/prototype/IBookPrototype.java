package com.prototype;

public interface IBookPrototype extends Cloneable{
	public IBookPrototype makeAClone();
}
