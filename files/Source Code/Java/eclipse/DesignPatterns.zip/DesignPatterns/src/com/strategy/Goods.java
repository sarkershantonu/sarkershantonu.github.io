package com.strategy;

public class Goods implements IStrategyBehaviour{
	public void carry() {
		System.out.println("carrying Goods");			
	}
}
