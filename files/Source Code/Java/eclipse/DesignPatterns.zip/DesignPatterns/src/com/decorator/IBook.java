package com.decorator;

public interface IBook {
	public String getDescription();
	public double getPrice();
}
