package com.mediator;

public class Testers extends Employee{
	public Testers(IMediator aMeadiator) {
		super(aMeadiator);
		System.out.println("Testers have signed up for schooling \n");
	}
}
