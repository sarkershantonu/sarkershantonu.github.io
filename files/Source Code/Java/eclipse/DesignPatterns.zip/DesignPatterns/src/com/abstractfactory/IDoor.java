package com.abstractfactory;

public interface IDoor {
	public String toString();
}
