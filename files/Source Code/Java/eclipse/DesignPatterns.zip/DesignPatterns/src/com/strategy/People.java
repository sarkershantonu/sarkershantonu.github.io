package com.strategy;

public class People implements IStrategyBehaviour{
	public void carry() {
		System.out.println("carrying People");			
	}
}

