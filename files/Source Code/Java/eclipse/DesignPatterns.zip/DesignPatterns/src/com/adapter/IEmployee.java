package com.adapter;

public interface IEmployee {
	public void attenOffice();
	public void joinMeeting();
	public void getDailyReport();
}
