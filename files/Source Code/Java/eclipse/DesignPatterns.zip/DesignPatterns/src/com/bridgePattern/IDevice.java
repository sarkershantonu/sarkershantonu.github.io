package com.bridgePattern;

public interface IDevice {
		public void connectDevice();
		public boolean validateDevice();
		public void ejectDevice();
}
