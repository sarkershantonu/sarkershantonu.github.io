package com.prototype;

public interface BookPrototype extends Cloneable{
	public BookPrototype makeAClone();
}
