package com.stateDesignPattern;

public interface IState {	
	public void charge();
	public void usbMount();
	public void adbConnect();
}
