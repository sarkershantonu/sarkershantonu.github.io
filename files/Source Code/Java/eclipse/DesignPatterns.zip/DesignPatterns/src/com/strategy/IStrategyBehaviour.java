package com.strategy;

public interface IStrategyBehaviour {
	public void carry();
}
