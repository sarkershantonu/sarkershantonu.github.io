package com.proxy;

public interface IBalanceInformation {
	public double getBalance();
}