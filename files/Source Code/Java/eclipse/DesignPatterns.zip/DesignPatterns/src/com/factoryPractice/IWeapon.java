package com.factoryPractice;

public interface IWeapon {
	public String toString();
}
