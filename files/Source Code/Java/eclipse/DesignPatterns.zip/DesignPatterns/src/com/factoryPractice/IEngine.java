package com.factoryPractice;

public interface IEngine {
	public String toString();

}
