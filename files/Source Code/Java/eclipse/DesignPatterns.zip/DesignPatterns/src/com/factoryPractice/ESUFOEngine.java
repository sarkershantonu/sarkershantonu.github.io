package com.factoryPractice;

public class ESUFOEngine implements IEngine{
	public ESUFOEngine(){
		System.out.println("UFOEngine created");
	}
	public String toString(){
		return "1000 mph";
	}
}
