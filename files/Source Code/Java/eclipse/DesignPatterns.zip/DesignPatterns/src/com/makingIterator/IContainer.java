package com.makingIterator;

public interface IContainer {
	public IIterator createIterator();
}
