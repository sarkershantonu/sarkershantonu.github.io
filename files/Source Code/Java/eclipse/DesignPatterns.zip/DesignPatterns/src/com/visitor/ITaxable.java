package com.visitor;
//The Visitable interface
public interface ITaxable {
	public double addTaxMonitor(ITaxMonitor taxMonitor);
}
