package com.observerPattern;

public interface IMyObserver {
	void update();
	void update(Object args);
}
