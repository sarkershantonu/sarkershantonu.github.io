package com.factoryPractice;

public class ESUFOBossEngine implements IEngine {
	public ESUFOBossEngine(){
		System.out.println("UFOBoss Engine created");
	}
	public String toString(){
		return "2000 mph";
	}
}
