package com.iteratorPattern;

public class Book {
	private String title; 
	public Book(String atitle){
		this.title=atitle;
	}
	public String getTitle() {
		return title;
	}
}
