package com.FactoryMethod;

public interface IProduct {
	public void showMe();
}
