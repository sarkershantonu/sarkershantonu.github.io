package com.abstractfactory;

public interface IFurniture {
	public String toString();
}
