package com.command;

public interface IReceiver {
	public void home();
	public void on();
	public void off();
	public void volumeUp();
	public void volumeDowne();
	public void back();
}
