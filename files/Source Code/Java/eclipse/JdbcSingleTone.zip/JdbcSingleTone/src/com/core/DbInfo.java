package com.core;

public class DbInfo {	
     public static String port = "3306";
     public static String dbName = "database_name";
     public static String hostIP = null;
     public static String userName = "username";
     public static String password = "password";
     public static String jdbc = null;
     public static String driver = "com.mysql.jdbc.Driver";
     public static String instance = null;
     public static String URL = "jdbc:mysql://localhost:3306/";//URL=driver:instance://IP:port   

}
