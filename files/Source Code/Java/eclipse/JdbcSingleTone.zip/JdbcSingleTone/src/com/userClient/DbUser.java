package com.userClient;

import com.core.*;

public class DbUser {
	public MySqlConn myDbConnection = MySqlConn.getDbConnection();	

}
