﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DbLocator
{
    public class Database
    {
        public string Name { get; set; }
        public string Remarks { get; set; }
        public int size { get; set; }

    }
}
