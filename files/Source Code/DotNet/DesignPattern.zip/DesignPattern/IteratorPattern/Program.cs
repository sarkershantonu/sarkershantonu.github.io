﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IteratorPattern
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
